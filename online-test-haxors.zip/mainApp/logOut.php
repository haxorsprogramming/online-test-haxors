<?php
session_start();
header('location:../');
session_destroy();
?>