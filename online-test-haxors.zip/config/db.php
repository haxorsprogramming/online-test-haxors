<?php
$link = new mysqli('localhost','root','','dbs_haxors');

?>